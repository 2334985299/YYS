// window.onload = function() {
// };

$(function () {

    // 目录+导航条
    function head_nav() {
        // head目录
        $('.head-game').hover(function () {
            $('.head-list').animate({
                height: '500px'
            }, 400)
        }, function () {
            $('.head-list').animate({
                height: '0px'
            }, 400)
        })
        $('.head-list').hover(function () {
            // 停止head-list收缩动画
            $(this).stop();
        }, function () {
            $(this).animate({
                height: '0px'
            }, 400)
        })

        // 导航条菜单显示隐藏
        var navnum = 0  // 定位
        $('.nav-box ul li').hover(function () {
            navnum = $(this).index()
            // console.log(navnum)  // 确认下标 来给subnav-box的孩子指路
            // console.log($('.subnav-box').children().index())  // 下标永为0！ 因为移进li中另一个的div时，原来的div隐藏了
            // console.log($('.subnav-box').children().eq(navnum - 1).find('a').length)  // 获取到当前div有a标签的个数，以此判断是否显示div。
            // if (navnum == 0 || navnum == 8 || navnum == 9 || navnum == 11 || navnum == 12 || navnum == 13 || navnum == 14) {    // 死方法 
            if ($('.subnav-box').children().eq(navnum - 1).find('a').length == 0) {
                $('.subnav-wrap').hide();
            } else {
                $('.subnav-wrap').show();
                // 因为$('.subnav-box').children()的下标永为0！
                // 所以当navnum=1时，由于15个导航文本我们只弄了14个div，第一个又不算$('.subnav-box').children(),故定位要-1。(也可以补上一个div，就可以直接定位)         
                // console.log($('.subnav-box').children().eq(navnum-1).index())   //li.index()=div.index()-1
                $('.subnav-box').children().eq(navnum - 1).show().siblings().hide();
            }
        }, function () {
            $('.subnav-wrap').hide();
            $('.subnav-box').children().eq(navnum - 1).hide();
        })
        $('.subnav-wrap').hover(function () {    // 目标转换
            $('.subnav-wrap').show();
            $('.nav-box ul li').eq(navnum).addClass('active')  // 由于目标转换，之前a:hover的选中的类的效果消失，故需在这添加选中类
            $('.subnav-box').children().eq(navnum - 1).show().siblings().hide();
        }, function () {
            $('.subnav-wrap').hide();
            $('.nav-box ul li').eq(navnum).removeClass('active')  // 由于添加了类，所以在离开时要去除
            $('.subnav-box').children().eq(navnum - 1).hide();
        })

        // 导航滚动吸顶
        $(window).scroll(function () {
            var windowY = $(window).scrollTop(); // 获取窗口距离顶部的距离
            if (windowY >= 54) {
                $('.nav-wrap').addClass('fixed')
            } else {
                $('.nav-wrap').removeClass('fixed')
            }
        })
    }
    head_nav()


    // 轮播图部分
    function swiper() {
        // 轮播图
        var mySwiper = new Swiper('.swiper', {
            direction: 'horizontal', // 垂直切换选项
            loop: true, // 循环模式选项
            autoplay: true,  // 自动播放
            effect: 'fade', // 淡入效果
        })

        // 标题栏切换
        $('.tab-title ul li').click(function () {
            // 修改点击菜单的样式
            $(this).addClass('on').siblings().removeClass('on');
            // 控制对应点击菜单的内容显示
            $('.tab-content').children().eq($(this).index()).fadeIn(1000).siblings().hide();
        })

        // 标题栏的轮播图效果
        num = 1 // 判断前后进退指针
        n1 = $('.news-right-swiper').children().eq(0).index()  //0
        n2 = $('.news-right-swiper').children().eq(1).index()  //1
        n3 = $('.news-right-swiper').children().eq(2).index()  //2   
        $('.news-down').click(function () {
            // n= $('.news-right-swiper').children().length
            // // $('.news-right-content'+n).addClass('z_index')
            // console.log($('.news-right-swiper').children().eq($(this).children().hasClass('z_index')))                    
            // console.log(n1,n2,n3)
            // n=$('.news-right-swiper').children().eq((n2+1)).index()
            // console.log(n)
            if (num == 1) {
                $('.news-right-swiper').children().eq((n2)).fadeIn().siblings().fadeOut()   // 淡入淡出
                // $('.news-right-swiper').children().eq((n2)).addClass('z_index').siblings().removeClass('z_index')  // 层级大小
                num++
            } else if (num == 2) {
                $('.news-right-swiper').children().eq((n3)).fadeIn().siblings().fadeOut()
                // $('.news-right-swiper').children().eq((n3)).addClass('z_index').siblings().removeClass('z_index')
                num++
                // $(this).css({ 'pointer-events': 'none' }) //无下一批即禁止点击
                // $(this).attr('title','当前为最后一批')
                $('.news-down').hide()
                $('.news-on').css('right', '80px')
            }
            // $('.news-on').css('display','block')
            $('.news-on').fadeIn()
        })
        $('.news-on').click(function () {
            if (num == 2) {
                $('.news-right-swiper').children().eq((n1)).fadeIn().siblings().fadeOut()
                num--
                $('.news-on').fadeOut()
                // $('.news-down').css({ 'pointer-events': 'auto' })
            } else if (num == 3) {
                $('.news-right-swiper').children().eq((n2)).fadeIn().siblings().fadeOut()
                num--
                // $('.news-down').css({ 'pointer-events': 'auto' })
                $('.news-down').show()
                $('.news-on').css('right', '140px')
            }
        })
    }
    swiper()


    
    // 切换到平安世界第三个选项函数:声优阵
    function syz() {
        $('.world-head-select-lis').children('li').click(function () {
            if ($(this).index() == 2) {
                $('.world-content-shengyou').fadeIn().siblings().hide()
                $('.world-head-select-search').hide()
            } else {
                $('.world-content-shengyou').hide().siblings().fadeIn()
            }
        })
    }
    syz()

    // 准备一个有不同式神的数组对象
    var cutArr = [
        [
            {
                name: '季',
                img1Url1: './img/c-1.png',
                img1Url2: './img/cc-1.png'
            },
            {
                name: '寻香行',
                img1Url1: './img/c-2.png',
                img1Url2: './img/cc-2.png'
            },
            {
                name: '神启荒',
                img1Url1: './img/c-3.png',
                img1Url2: './img/cc-3.png'
            },
            {
                name: '须佐之男 ',
                img1Url1: './img/c-4.png',
                img1Url2: './img/cc-4.png'
            },
            {
                name: '嘴平伊之助 ',
                img1Url1: './img/c-5.png',
                img1Url2: './img/cc-5.png'
            }
        ], [
            {
                name: '晴明',
                img1Url1: './img/b-1.png',
                img1Url2: './img/bb-1.png',
            },
            {
                name: '神乐',
                img1Url1: './img/b-2.png',
                img1Url2: './img/bb-2.png'
            },
            {
                name: '源博雅',
                img1Url1: './img/b-3.png',
                img1Url2: './img/bb-3.png'
            },
            {
                name: '八百比丘尼',
                img1Url1: './img/b-4.png',
                img1Url2: './img/bb-4.png'
            }
        ]
    ]

    // 切换式神动画和名称初始化
    function initCut(cutArr) {  // 局部变量和全局变量，优先使用局部变量
        // 进场动画
        $('.world-content-content').children().children().each(function (index) {
            // if(index == 0){
            //     // 为了防止，频繁切换动画时，动画等待执行时间过长，每次执行动画前，先清空
            //     $(this).animate({
            //         left:'-140px',
            //         opacity:'1'
            //     },800)
            // }else{
            //     $(this).animate({
            //         right:'-140px',
            //         opacity:'1'
            //     },800)
            // }

            // 初始化取出对应图片
            $(this).attr('src', index == 0 ? cutArr[0].img1Url1 : cutArr[0].img1Url2)

            // 回到默认位置
            $(this).css({
                [index == 0 ? 'left' : 'right']: '-240px'
            })

            $(this).stop().animate({
                // 在es5中对象的属性名，不能是变量或者其他语句
                // 在es6中使用[]可以在对象属性中使用变量
                [index == 0 ? 'left' : 'right']: '-140px', opacity: '1'
            })
        })

        // 初始化左右两边的值
        $('.world-content-jt .name').each(function (index) {
            // if(index == 0){
            //     $(this).html(cutArr[cutArr.length-1].name)
            // }else{
            //     $(this).html(cutArr[1].name)
            // }
            var key = index == 0 ? cutArr.length - 1 : 1;
            $(this).html(cutArr[key].name)
        })

        // 调用切换的方法
        cut(cutArr)
    }
    initCut(cutArr[0])


    // 切换式神的操作
    function cut(cutArr) {
        var num = 0;   // 记录值
        $('#btnnext').click(function () {
            num = num >= cutArr.length - 1 ? 0 : ++num;
            cutAn(num, cutArr)
        })
        $('#btnpre').click(function () {
            num = num <= 0 ? cutArr.length - 1 : --num;
            cutAn(num, cutArr)
        })
    }

    // 切换动画函数
    function cutAn(num, cutArr) {
        // 切换动画图
        $('#content').children().children().each(function (index) {
            if (index == 0) {
                $(this).stop().animate({
                    left: '-240px',
                    opacity: '0'
                }, function () {    // 回调函数，动画结束时执行
                    $(this).attr('src', cutArr[num].img1Url1).stop().animate({
                        left: '-140px',
                        opacity: '1'
                    }, 800)
                })
            } else {
                $(this).stop().animate({
                    right: '-240px',
                    opacity: '0'
                }, function () {    // 回调函数，动画结束时执行
                    $(this).attr('src', cutArr[num].img1Url2).stop().animate({
                        right: '-140px',
                        opacity: '1'
                    }, 800)
                })
            }
        })
        // 切换名称
        $('.world-content-jt .name').each(function (index) {
            if (index == 0) {
                // 左边的名字，上一个名字
                $(this).html(cutArr[num - 1 < 0 ? cutArr.length - 1 : num - 1].name)
            } else {
                // 右边的名字，下一个名字
                $(this).html(cutArr[num + 1 > cutArr.length - 1 ? 0 : num + 1].name)
            }
        })
    }


    //切换平安世界选项函数
    function cutlis(cutArr) {
        // 移入事件
        $('.world-head-select-lis').children('li').hover(function () {
            $(this).addClass('hover-active')
        }, function () {
            $(this).removeClass('hover-active')
        })

        $('.world-head-select-lis').children('li').click(function () {
            $(this).addClass('active').siblings().removeClass('active')
            // 切换数组
            initCut(cutArr[$(this).index()])
            // 判断搜索框是否显示
            $(this).index() != 0 ? $('.world-head-select-search').hide() : $('.world-head-select-search').show()
        })
    }
    cutlis(cutArr) // 传递完整的数组进来

    // 游戏攻略
    function strategy(){
        $('.strategy-select').children('li').hover(function(){
            n = $(this).index()
            // $('.strategy-select').children().children().eq(n-1).hide()
            $('.strategy-select').children().children().eq(n-1).hide().parent().siblings().children().show()
            $(this).addClass('active').siblings().removeClass('active')
            $('.strategy-details').children('ul').eq(n).fadeIn().siblings().hide(10)
        })
    }
    strategy()

    // 同人手账
    function handbook(){
        $('.hot_action-xuan').children().hover(function(){
            $(this).addClass('on').siblings().removeClass('on')
            n = $(this).index()
            $('.hot_action_two').children().eq(n).fadeIn().siblings().hide()
        })
        var n=0;  // 热门活动指针
        setInterval(function(){
            // console.log(n)
            $('.hot_action-xuan').children().eq(n).addClass('on').siblings().removeClass('on')
            $('.hot_action_two').children().eq(n).fadeIn().siblings().fadeOut()
            n++
            if(n==3){
                n=0
            }
        },3500)
        var s=0;  // 热门作品指针
        setInterval(function(){        
            $('.hot_opus-two').children().eq(0).children().eq(s).children().fadeIn().parent().siblings('li').children().fadeOut()
            $('.hot_opus-two').children().eq(1).children().eq(s).children().fadeIn().parent().siblings().children().fadeOut()
            $('.hot_opus-two').children().eq(2).children().eq(s).children().fadeIn().parent().siblings().children().fadeOut()
            s++
            if(s==3){
                s=0
            }
        },4000)
    }
    handbook()
})